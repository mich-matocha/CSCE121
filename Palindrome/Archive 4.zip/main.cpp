#include "functions.h"
#include <string>
#include <vector>
#include <iostream>

using namespace std;

int main(int argc, char** argv)
{
	string flag = "";
	int startPoint = 0;
	vector <char> flagElements {}; 
	bool caseFlag = false;
	bool spaceFlag = false;

	if(argc < 2 || argv[1][0] == '-' && !isValidFlag(argv[1]))
	{
		printUsageInfo(argv[0]);
		return 0;
	}

	if(argv[1][0] == '-')
	{
		startPoint = 1;
		flag = argv[1];
		for(int i = 0; i < flag.size(); ++i)
		{
			if(tolower(flag[i]) == 'c')
			{
				caseFlag = true;
			}

			if(tolower(flag[i]) == 's')
			{
				spaceFlag = true;
			}
		}
	}
	else if(argv[2][0] == '-')
	{
		startPoint = 2;
		flag = argv[2];
		for(int i = 0; i < flag.size(); ++i)
		{
			if(tolower(flag[i]) == 'c')
			{
				caseFlag = true;
			}

			if(tolower(flag[i]) == 's')
			{
				spaceFlag = true;
			}
		}
	}

	bool palindrome = false;
	string word = "";
	string wordProcessed = "";

	for(int i = startPoint + 1; i < argc; ++i) //starting after the executable and looping through the argument list
	{
		word = argv[i];
		wordProcessed = word;
		wordProcessed = removePunctuation(wordProcessed);
		cout << wordProcessed << endl;
		palindrome = isPalindrome(wordProcessed, caseFlag, spaceFlag);
		cout << palindrome << endl << !palindrome << endl;
		cout << "\"" << word << "\" is ";

		if(!palindrome)
		{
			cout << "not ";
		}

		cout << "a palindrome." << endl;
		palindrome = false;
	}
	return 0;
}