#include "functions.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

bool isValidFlag(string flag)
{
	if(flag.size() <= 3 && flag[0] == '-' && (tolower(flag[1]) == 'c' || tolower(flag[1]) == 's'))
	{
		if(flag.size() == 3 && (tolower(flag[2]) == 'c' || tolower(flag[2]) == 's'))
		{
			return true;
		}
		else if(flag.size() != 3)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}

void printUsageInfo(string exe)
{
	cout << "Usage: " << exe << " [-c] [-s] string..." << endl;
	cout << "-c: turn on case sensitivity" << endl << "-s: turn off ignoring spaces" << endl;
}

int isPalindrome(string word, bool caseFlag, bool spaceFlag)
{	
	preprocessString(word, caseFlag, spaceFlag);
	return isPalindromeR(word);
}

int isPalindromeR(string word) //recursive helper function, case sensitive and include spaces as characters
{
	if(word.size() == 0 || word.size() == 1)
	{
		return 1;
	}
	else if(word[0] == word[word.size() - 1])
	{
		isPalindromeR(word.substr(1, word.size() - 2));
	}
	else
	{
		return 0;
	}
}

string toLower(string word)
{
	string ret = "";
	for(int i = 0; i < word.size(); ++i)
	{
		ret += tolower(word[i]);
	}
	return ret;
}

string preprocessString(string word, bool caseFlag, bool spaceFlag)
{
	string ret = word;
	if(!caseFlag) //if the case of the letters doesn't matter
	{
		ret = toLower(ret);
	}
	if(!spaceFlag && word.find(" ") != -1) //if spaces don't matter
	{
		ret.erase(' ');
	}
	return ret;
}

string removePunctuation(string word)
{
	int index = -1;
	vector<string> punctuation {".", ",", "/", "\\", "!", "@", "#", "$", 
		"%", "^", "&", "*", "(", ")", "-", "_", "=", "+", "[", "]", "[", "]", "|"};
	for(int i = 0; i < punctuation.size(); ++i)
	{
		index = word.find(punctuation.at(i));
		while(index != -1)
		{
			word.erase(index, index + 1);
			index = word.find(punctuation.at(i));
		}
	}
	return word;
}
