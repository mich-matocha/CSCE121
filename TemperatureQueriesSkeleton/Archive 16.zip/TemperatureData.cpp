/*
 * TemperatureData.cpp
 *
 *  Created on: Jul 16, 2018
 *      Author: Michaela Matocha
*/

#include "TemperatureData.h"
using namespace std;

TemperatureData::TemperatureData()
{id = ""; year = 1800; month = 1; temperature = 0;} //initialize everything

TemperatureData::TemperatureData(string id, int year, int month, double temperature)
{this->id = id; this->year = year; this->month = month; this->temperature = temperature;} //initialize everything


TemperatureData::~TemperatureData() {} // You should not need to implement this

bool TemperatureData::operator<(const TemperatureData& b) { //maybe this is actually what's going wrong??

	if(id < b.id)
	{
		return true;
	}
	else if(id > b.id) //comparing strings is confusing??
	{
		return false;
	}

	if(year < b.year && id == b.id)
		return true;
	else if(year > b.year)
	{
		return false;
	}

	if(month < b.month && id == b.id && year == b.year)
		return true;
	else if(month > b.month)
	{
		return false;
	}

	if(temperature < b.temperature && id == b.id && year == b.year && month == b.month)
		return true;
	else
		return false;
}
