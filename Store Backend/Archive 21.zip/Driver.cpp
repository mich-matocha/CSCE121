#include <string>
#include "Customer.h"
#include "Product.h"
#include "Store.h"
#include <iostream>

int main()
{
	

	/*Product p(124, "dog");
	cout << "\"" << p.getDescription() << "\"" << endl;
	p.setDescription("This is very cute.");
	cout << "\"" << p.getDescription() << "\"" << endl;*/
}