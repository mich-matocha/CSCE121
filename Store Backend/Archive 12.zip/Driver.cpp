#include <string>
#include "Customer.h"
#include "Product.h"
#include "Store.h"
#include <iostream>

int main()
{
	Store s("Things to Buy");
	s.addProduct(123,"towel");
	cout << s.listProducts()<< endl;
	s.getProduct(123).setName("Dog");
	cout << s.listProducts() << endl;
	Product p = s.getProduct(123);
	s.getProduct(123).setDescription("For drying");
	cout << "\"" << p.getDescription() << "\"" << endl;
	cout << s.listProducts() << endl;
	cout << s.getProduct(123).getDescription() << endl;

	/*Product p(124, "dog");
	cout << "\"" << p.getDescription() << "\"" << endl;
	p.setDescription("This is very cute.");
	cout << "\"" << p.getDescription() << "\"" << endl;*/
}